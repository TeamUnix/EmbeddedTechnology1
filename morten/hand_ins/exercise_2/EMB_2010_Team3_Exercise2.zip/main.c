//============================================================================
// Name        : main.c
// Author      : Team3#Dennis, Theis, Paulo
// Version     :
// Copyright   : Don't copy this very secret code. Steal it!
// Description : Simple UART loopback
//============================================================================
#include "lpc2468.h"
#include "framework.h"
#include "uart.h"

/* main loop
 * basic CPU initialization is done here.
 */
int main(void)
{
	char c;

	/* init low level stuff */
	lowLevelInit();

	/*initialize uart #0, #2: 115200 baud, 8N1*/
	initUart(UART0, B115200(Fpclk), UART_8N1);
	initUart(UART2, B115200(Fpclk), UART_8N1);
	while(1){
		c = getkey(UART0);
		sendchar(UART0, c+1);

		c = getkey(UART2);
		sendchar(UART2, c+1);
	}

	return 0;
}
