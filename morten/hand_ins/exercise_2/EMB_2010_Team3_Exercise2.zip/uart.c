//============================================================================
// Name        : uart.c
// Author      : Team3#Dennis, Theis, Paulo
// Version     :
// Copyright   : Don't copy this very secret code. Steal it!
// Description : Simple UART loopback
//============================================================================

/******************************************************************************
 * Includes
 *****************************************************************************/
#include <lpc2468.h>
#include "uart.h"

/*****************************************************************************
 *
 * Description:
 *    Initialize UART
 *
 * Parameters:
 * 	  [in] uart_int - Choose which UART interface to initialize.
 *
 *    [in] div_factor  - UART clock division factor to get desired bit rate.
 *                       Use definitions in uart.h to calculate correct value.
 *    [in] mode        - transmission format settings. Use constants in uart.h
 *
 ****************************************************************************/
void initUart(unsigned char uart, unsigned short div_factor, unsigned char mode)
{
	switch (uart){
		case UART0:

			//enable UART pins in GPIO (P0.2 = TxD0, P0.3 = RxD0)
			PINSEL0 |= ((1 << 4) | (1 << 6));

			//set the bit rate = set uart clock (pclk) divisionfactor
			U0LCR = 0x80; //enable divisor latches (DLAB bit set, bit 7)
			U0DLL = (unsigned char) div_factor; //write division factor LSB
			U0DLM = (unsigned char) (div_factor >> 8); //write division factor MSB

			//set transmissiion and fifo mode
			U0LCR = (mode & ~0x80); //DLAB bit (bit 7) must be reset
			break;
		case UART1:
			//enable UART pins in GPIO (P0.15 = TxD0, P1.0 = RxD0)
			//PINSEL0 |= (1 << 30);
			//PINSEL1 |= (1 << 0);
			PINSEL7 |= ((1 << 0) | (1 << 1) | (1 << 2) | (1 << 3));

			//set the bit rate = set uart clock (pclk) divisionfactor
			U1LCR = 0x80; //enable divisor latches (DLAB bit set, bit 7)
			U1DLL = (unsigned char) div_factor; //write division factor LSB
			U1DLM = (unsigned char) (div_factor >> 8); //write division factor MSB

			//set transmissiion and fifo mode
			U1LCR = (mode & ~0x80); //DLAB bit (bit 7) must be reset
			break;
		case UART2:
			//enable UART pins in GPIO (P0.10 = TxD0, P0.11 = RxD0)
			PINSEL0 |= ((1 << 20) | (1 << 22));

			//set the bit rate = set uart clock (pclk) divisionfactor
			U2LCR = 0x80; //enable divisor latches (DLAB bit set, bit 7)
			U2DLL = (unsigned char) div_factor; //write division factor LSB
			U2DLM = (unsigned char) (div_factor >> 8); //write division factor MSB

			//set transmissiion and fifo mode
			U2LCR = (mode & ~0x80); //DLAB bit (bit 7) must be reset
			break;
		case UART3:
			//enable UART pins in GPIO (P0.0 = TxD0, P0.1 = RxD0)
			PINSEL0 |= ((1 << 1) | (1 << 3));

			//set the bit rate = set uart clock (pclk) divisionfactor
			U3LCR = 0x80; //enable divisor latches (DLAB bit set, bit 7)
			U3DLL = (unsigned char) div_factor; //write division factor LSB
			U3DLM = (unsigned char) (div_factor >> 8); //write division factor MSB

			//set transmissiion and fifo mode
			U3LCR = (mode & ~0x80); //DLAB bit (bit 7) must be reset
			break;
		default:
			break;
	}

}

/*****************************************************************************
 *
 * Description:
 *    Blocking output routine, i.e., the routine waits until the
 *    uart tx register is free and then sends the character.
 *
 * Params:
 *    [in] charToSend - The character to print
 *
 ****************************************************************************/
int sendchar(unsigned char uart, int ch)
{
	int count = 0;
	switch (uart){
		case UART0:
			if(ch == '\n'){
				while(!(U0LSR & 0x20));
				U0THR = '\r';
			}
			while(!(U0LSR & 0x20));
			return (U0THR = ch);
			break;
		case UART1:
			if(ch == '\n'){
				while(!(U1LSR & 0x20) && (count < 100));
				U1THR = '\r';
			}
			while(!(U1LSR & 0x20) && (count < 100));
			return (U1THR = ch);
			break;
		case UART2:
			if(ch == '\n'){
				while(!(U2LSR & 0x20));
				U2THR = '\r';
			}
			while(!(U2LSR & 0x20));
			return (U2THR = ch);
			break;
		case UART3:
			if(ch == '\n'){
				while(!(U3LSR & 0x20));
				U3THR = '\r';}
			while(!(U3LSR & 0x20));
			return (U3THR = ch);
			break;
		default:
			break;
	}
	return 0;
}

/*****************************************************************************
 *
 * Description:
 *    Blocking function that waits for a received character. 
 *
 * Return:
 *    The received character. 
 *
 ****************************************************************************/
int getkey(unsigned char uart)
{
	switch (uart){
		case UART0:
			while(!(U0LSR & 0x01));
			return (U0RBR);
			break;
		case UART1:
			while(!(U1LSR & 0x01));
			return (U1RBR);
			break;
		case UART2:
			while(!(U2LSR & 0x01));
			return (U2RBR);
			break;
		case UART3:
			while(!(U3LSR & 0x01));
			return (U3RBR);
			break;
		default:
			break;
	}
	return 0;
}
